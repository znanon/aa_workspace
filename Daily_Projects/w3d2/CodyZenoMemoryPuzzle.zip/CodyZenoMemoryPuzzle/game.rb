require_relative "board.rb"
require_relative "human_player.rb"

class Game

    attr_reader :player1, :player2

    def initialize(length=4)
        @board = Board.new(length)
        @player1 = HumanPlayer.new
        @player2 = HumanPlayer.new
        @currentplayer = @player1
        self.play
    end

    def play 
        @board.populate
        @board.hide_all
        @board.render
        while !game_over?
            self.turn
            
        end    
    end

    def switch_player!
        if @currentplayer == @player1
            @currentplayer = @player2
        else   
            @currentplayer = @player1
        end
    end

    def turn
        
        first_guess = @currentplayer.make_guess
        @board[first_guess].reveal
        system("clear")
        @board.render
        
        second_guess = @currentplayer.make_guess
        while 
        @board[second_guess].reveal
        system("clear")
        @board.render

        if @board[first_guess].card_info != @board[second_guess].card_info
            sleep(3)
            system("clear")
            @board[first_guess].hide
            @board[second_guess].hide
            @board.render
        else
            @currentplayer.score += 1
        end
        self.switch_player!
    end

    def validate_guess
        guess = @currentplayer.make_guess
        while guess
    end

    def game_over?
        if @board.won?
            puts "You won! Player1 score: #{player1.score}"
            puts "Player 2 score: #{player2.score}"
        end
    end
end
