require_relative "card.rb"

class Board
    attr_reader :grid
    def initialize(n)
        @size = n**2
        @grid = Array.new(n) {Array.new(n, "_")}
        @used_cards = []
    end

    def populate
        i = 0
        while i < @size
            card1 = Card.new
            while @used_cards.include?(card1.card_info)
                card1 = Card.new
            end
            card2 = card1.dup
            @used_cards << card1.card_info
            idx1 = rand(0...@grid.length).floor
            idx2 = rand(0...@grid.length).floor
            while @grid[idx1][idx2].is_a?(Card)
                idx1 = rand(0...@grid.length).floor
                idx2 = rand(0...@grid.length).floor
            end
            @grid[idx1][idx2] = card1
            while @grid[idx1][idx2].is_a?(Card)
                idx1 = rand(0...@grid.length).floor
                idx2 = rand(0...@grid.length).floor
            end
            @grid[idx1][idx2] = card2
            i += 2
        end
    end

    def render
        @grid.each do |row|
            new_line = ""
            row.each do |card|
                new_line += card.card_info + " "
            end
            puts new_line
        end
        nil
    end

    def hide_all
        @grid.each do |row|
            row.each do |card|
                card.hide
            end
        end
        nil
    end

    def [](pos)
        row, col = pos
        @grid[row][col]
    end

    def reveal(pos)
        if self[pos].card_info == "_"
            self[pos].reveal
        end
        self[pos].card_info
    end

    def won?
        @grid.each do |row|
            row.each do |card|
                return false unless card.up
            end
        end
        true
    end
end