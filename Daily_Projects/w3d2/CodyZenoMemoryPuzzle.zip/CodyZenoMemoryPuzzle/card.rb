class Card
    CARD_COLLECTION = ("A".."Z").to_a

    attr_reader :up
    def initialize
        @face_value = CARD_COLLECTION.sample
        @up = true
    end

    def card_info
        if @up
            @face_value 
        else
            "_"
        end
    end

    def hide
        @up = false
    end

    def reveal
        @up = true
    end

    def ==(other_card)
        self.card_info == other_card.card_info
    end
end