require_relative "room"

class Hotel
    attr_reader :rooms
    def initialize(name, rooms)
        @name = name
        @rooms = {}
        rooms.each do |k, v|
            @rooms[k] = Room.new(v)
        end 
    end 

    def name
        words = @name.split(" ")
        words.map! do |word|
            word.capitalize
        end 
        words.join(" ")
    end

    def room_exists?(room)
        @rooms.has_key?(room)
    end

    def check_in(person, room)
        if !self.room_exists?(room)
            p "sorry, room does not exist"
        elsif
            @rooms[room].add_occupant(person)
            p "check in successful"
        else
            p "sorry, room is full"
        end
    end

    def has_vacancy?
        @rooms.values.each do |cap|
            if cap.available_space > 0
                return true
            end
        end
        false
    end

    def list_rooms
        @rooms.each do |k, v|
            puts k  + "#{v.available_space}" 
        end 
    end 
end
