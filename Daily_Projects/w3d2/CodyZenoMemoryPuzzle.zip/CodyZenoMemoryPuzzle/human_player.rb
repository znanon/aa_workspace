class HumanPlayer
    
    attr_reader :name
    attr_accessor :score

    def initialize
        puts "Enter a name:"
        @name = gets.chomp
        @score = 0
    end

    def make_guess
        puts "Enter card coordinates"
        pos = gets.chomp.split(" ")
        pos.map! {|num| num.to_i}
    end


end